jQuery(document).ready(function(){
   jQuery(".qodef-mobile-header-opener path").attr('fill', 'rgb(255,255,255)');
});